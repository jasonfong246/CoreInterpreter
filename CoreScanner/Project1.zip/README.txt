Name: Jason Fong Shen Yik
Files for submission: Main.java Scanner.java Core.java

Special Features: 
There are no special features or additional class/method I made for the lab. I've only utilize the methods provided.
Scanner method: Scans the file and reads line by line. The tokens are also separated by white spaces. Inside the scanner method, it also has a method
that checks for symbols that interconnects with the token.
nextToken method: I've only used this method to increment onto the next token.
currentToken method: See that which CORE matches the current token.
getID method: Gets the Identifier name and returns it as string value
getCONST method: Gets the constant value and return it as integer

Bugs: There are no bugs for this java class I've made. Everything runs smoothly when I do "./tester.sh"
